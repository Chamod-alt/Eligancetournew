package travora.travora.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import travora.travora.model.SelecttourReject;

public interface SelecttourRejectrepository extends JpaRepository<SelecttourReject ,Long> {
    
}
