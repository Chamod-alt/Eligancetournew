package travora.travora.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import travora.travora.model.SelecttourAccept;

public interface SelecttourAcceptrepository extends JpaRepository<SelecttourAccept , Long> {
    
}
