package travora.travora.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import travora.travora.model.Selectiontour;
public interface Selectiontourrepository extends JpaRepository<Selectiontour, Long> {
    
}