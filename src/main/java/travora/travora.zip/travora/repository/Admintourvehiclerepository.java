package travora.travora.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import travora.travora.model.Admintourvehicle;

public interface Admintourvehiclerepository extends JpaRepository<Admintourvehicle,Long> {

    
} 
